const assert = require('assert');
const Student = require('../src/students');

describe('Delete the records', (done) => {
   let student1
   
   beforeEach(() => {
    student1 = new Student({
        name: 'Peter'
    });
    student1.save()
    .then(() => done()
    )
   });
// delete by ID
   it('Delete by ID', (done) => {
    Student.findByIdAndDelete(student1._id)
    .then(() => Student.findOne({name: 'Peter'}))
    .then((student)=> {
        assert(student === null)
        
        done()
        })
    })
    
   //delete by name
   it('delete by name', (done) => {
    Student.findOneAndDelete({name: 'Peter'})
    .then(() =>
        Student.findOne({
            _id:student1._id
        }))
    .then((student) => {
        assert(student === null)
        done()
    })
   })


    //delete Peter 
   it('delete Peter', (done) => {
    Student.deleteOne({_id:student1._id})
    .then(() =>Student.findOne({name: 'Peter'}))
    .then((student) => {
        assert(student === null)
        done()
    });
   });
});