// import mongoose
const mongoose=require('mongoose')

// connect to database, student_test is the db name
mongoose.connect("mongodb://localhost/students_test")

// check if it is connected
mongoose.connection

// once method waches for mongoDB to connect the first time once an event occurred
    .once('open',()=>{console.log("\n-------------------connected to mangodb-----------------------\n")
    })
    // on watches for error in the connection
    .on('error',(e)=>{
        console.log('Error connecting...',e)
    })
// clear previous db connections
beforeEach((done)=>{
    mongoose.connection.collections.students.drop()
    done()
})
