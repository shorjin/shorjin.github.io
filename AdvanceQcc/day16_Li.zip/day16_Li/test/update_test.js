const assert = require('assert');
const Student = require('../src/students');

describe('Updating records', () => {
    let student1, student2;

    beforeEach((done) => {
        student1 = new Student({name: 'Peter', studentNumber: 123});
        student2 = new Student({name: 'Peter', studentNumber: 210});

        student1.save()
        student2.save()    
            .then(() => {done()});
    });
// update the student number of one of the peter to 110
    // it("Update the student number of one of the peter", async () => {
    //     const student = await Student.updateOne({name: "Peter"}, {studentNumber: 110});
    //     const res = await Student.find({});
    //     assert(res[0].studentNumber === 110);
    // });
// update the student number of all the Peter to 110
    it("update the student number of all the Peter", async () => {
        const student = await Student.updateMany({name: "Peter"}, {studentNumber: 110});
        const res = await Student.find({});
        assert(res[0].studentNumber === 110&& res[1].studentNumber === 110);
    })
});

    // it('Set and Save', () => {
    //     student1.set('name', 'Ann')
    //     student1.save()
    //     .then(() => {Student.find({})})
    //     .then((students) => {
    //         assert(students[0].name === 'Ann')
    //         done()
    //     })
   
