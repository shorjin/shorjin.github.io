// assert is used to compare two boolean values it is used in mocha to test data before sending data to the db.if assert returns true,data will be sent.
const assert=require('assert')
const Student=require("../src/students")

// create description function
describe("Create the first data",(done)=>{
    it('save the student',()=>{
    //    create the new student
    const student1=new Student({name:'Peter'})
    // create/save the new student in the db
    student1.save()
    .then(()=>{
        assert(!student1.isNew)
        // console.log(assert('testing student'+student1.isNew))
        done()
    })
    })
})