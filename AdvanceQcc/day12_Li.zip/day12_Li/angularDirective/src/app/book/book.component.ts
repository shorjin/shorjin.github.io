import { Component } from '@angular/core';
import { BookRepository } from './repository.model';
import { Book } from './book.model';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent {
model: BookRepository=new BookRepository()

addBook(){
  this.model.addBook(new Book(4,'Kids science','National Geographic',56))
}

deleteBook(book:Book) {
  this.model.deleteBook(book)

}
updateName(book:Book){
  book.name="UPDATED Name"
}
updatePrice(booK:Book){
  booK.price=88
}
}


