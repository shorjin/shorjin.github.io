import {User} from './user.model';
export class dataSource{
    private users:User[]
    constructor(){
        this.users=new Array<User>(
            new User(1,'Xiaojin Li','shorjin09@gmail.com')
        )
    }
    getUser():User[]{
        return this.users
    }
}