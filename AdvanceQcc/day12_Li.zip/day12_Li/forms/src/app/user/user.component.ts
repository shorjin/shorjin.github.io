import { Component } from '@angular/core';
import {User} from "./user.model"
import { UserRespository } from './repository.model';

@Component({
  selector: 'user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent {
model: UserRespository =new UserRespository()
newUser: User=new User();

get jsonUser(){
  return JSON.stringify(this.newUser)
}
addUser(u:User){
  console.log("New User is"+this.jsonUser)
}
displayLog(model:any){
  console.log(model)
}
}
