import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'angular_component';


  // property binding
isDiabled:boolean=true
// interploation binding
btnText:string ="I'm disable"

// set button to be active in 5 seconds ,here 5000=milliseconds
constructor(){
  setTimeout(()=>{
    this.isDiabled=false
    this.btnText='click Now!'
  },5000)
}
// event binding
prod1:string="product 1 added"
totolProd1:number=20
totalProd1Added:number=0
btnDisabled:boolean=false
btnProdText:string='Add product 1'

addProduct(){
  this.totolProd1--
  this.totalProd1Added++
  if(this.totolProd1==0){
    this.btnDisabled=true
    this.btnProdText="out of stock"
  }
}











}
