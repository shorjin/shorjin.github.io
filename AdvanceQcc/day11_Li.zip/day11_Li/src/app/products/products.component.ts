import { Component } from "@angular/core";
@Component({
    selector:"products",//selecting a <product></product> tag
    templateUrl:'./products.Component.html'
})
export class ProductsComponents{
    
}