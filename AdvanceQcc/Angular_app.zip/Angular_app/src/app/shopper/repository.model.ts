import { Shopper } from "./shooper.model";
import { dataSource } from "./dataSource.model";

export class ShopperRepositroy{
    private dataSource : dataSource
    private shoppers : Shopper[];
    constructor(){
        this.dataSource=new dataSource()
        this.shoppers=new Array<Shopper>()
        this.dataSource.getShopper().forEach(s=>this.shoppers.push(s))
    }
    getShoppers(){
        return this.shoppers
    }

    addShopper(shooper:Shopper){
        this.shoppers.push(shooper)
    }
}