import { Component } from "@angular/core";

@Component({
    selector: 'shopper',
    templateUrl: './shopper.component.html',
    styleUrls: ['./shopper.component.css']
})
export class ShopperComponent {
    quantity = 20; // Initial quantity
    selectedQuantity = 1; // Default selected quantity
    cartItems: any[] = [];
    showCart: boolean = false;
  
    addToBag() {
        if (this.selectedQuantity <= this.quantity && this.selectedQuantity > 0) {
          const item = {
            name: 'Iphone 14 Pro Max', 
            price: 69, 
            quantity: this.selectedQuantity
          };
          this.cartItems.push(item);
          this.quantity -= this.selectedQuantity;
          this.selectedQuantity = 1; // Reset the selected quantity
          this.showCart = true; // Show the shopping cart
        } else {
          alert('Invalid quantity or item out of stock');
        }
}
}