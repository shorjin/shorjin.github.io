import { Shopper } from "./shooper.model";
export class dataSource{
    private shoppers:Shopper[]
    constructor(){
        this.shoppers=new Array <Shopper>(
            new Shopper(1,"Xiaojin LI","shrojin09@gmail.com",1,69.99)
        )
    }
    getShopper():Shopper[]{
        return this.shoppers
    }
}