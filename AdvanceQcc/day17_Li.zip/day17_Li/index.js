const express = require('express');
const bodyParse = require('body-parser');
const mongoose = require('mongoose');

// create an app using express
const app = express();

app.use(bodyParse.json());
app.use(express.static('public'));
app.use(bodyParse.urlencoded({extended: true}));

// connect the database
mongoose.connect('mongodb://localhost/userlogin', {useNewUrlParser: true, useUnifiedTopology: true});

// check the connection
const db = mongoose.connection
db.once('open', () => {console.log('Connected to DB')});
db.on('Error', (error) => {console.log('Error connecting', error)});

// create app endpoints
app.get('/', (req, res) => {res.redirect('index.html')}).listen(3000);

// posting the form
app.post('/login', (request, response) => {
    try {
        // get data from index.html
        const username = request.body.username
        const password = parseInt(request.body.password)

        // test the app reading the password
        console.log(`entered username ${username}, entered Password ${password}`)

        // get data from database
        const usermail = db.collection('users').findOne(
            {username: username}, (err, res) => {
                if (res === null) {
                    response.send('Information does not match')
                } else if (err) {
                    throw err
                }

                if (res.password === password) {
                    console.log('Login successful!')
                    return response.redirect('login.html')
                } else {
                    console.log("Password doesn't match")
                    response.send("PASSWORD DOES NOT MATCH")
                }
            })

    } catch (error) {
        console.log('Invalid information')
    }
});