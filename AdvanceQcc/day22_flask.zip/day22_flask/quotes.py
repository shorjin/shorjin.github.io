from flask import Flask,render_template,request,redirect,url_for
from flask_sqlalchemy import SQLAlchemy
from datetime import date
app=Flask(__name__)

# CONNECTION from form to databse
app.config["SQLALCHEMY_DATABASE_URI"] = "postgresql+psycopg2://postgres:password@localhost/quotes"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# transfer data from form to database
db=SQLAlchemy(app)

# create a model to quotes db
class Favquotes(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    author=db.Column(db.String(30))
    quote=db.Column(db.String(2000))
    date = db.Column(db.Date,default=date.today)

@app.route('/')
def index():
    result=Favquotes.query.all()
    return render_template('index.html',result=result)
    """
    color=['orange','lightblue','magenta']
    return render_template('index.html',quote1="",colors=color)
    """
@app.route('/about')
def about():
    return '<h1> About us</h1>'

@app.route('/quotes')
def quotes():
    return render_template('quotes.html')

# Route to reset the database
@app.route('/reset-database', methods=['POST'])
def reset_database():
    try:
        # Delete all data from the Favquotes table
        db.session.query(Favquotes).delete()
        db.session.commit()
        return redirect(url_for('index'))
    except Exception as e:
        return f"An error occurred: {str(e)}"




@app.route('/process',methods=["POST"])
def process(): 
    author=request.form["author"]
    quote=request.form["quote"]
    
    user_input_date = request.form["date"]
    if user_input_date:
        try:
            parsed_date = date.fromisoformat(user_input_date)
        except ValueError:
            # Handle invalid date format here
            return "Invalid date format"
    else:
        parsed_date = date.today()

    quotedate = Favquotes(author=author, quote=quote, date=parsed_date)

   
    db.session.add(quotedate)
    db.session.commit()
    return redirect(url_for('index'))
with app.app_context():db.create_all()


