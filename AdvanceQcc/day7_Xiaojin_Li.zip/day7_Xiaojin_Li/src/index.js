import React from 'react';
import ReactDOM from 'react-dom/client';
import User from "./comments"
import bunny from"./images/bunny.png"
import fox from"./images/fox.png"
import deer from "./images/deer.png"
import User_feedback from "./userfeedback"
import CardExample from "./card"
import pic1 from "./images/1.jpg"
import pic2 from "./images/2.jpg"
import pic3 from "./images/3.jpg"
import pic4 from "./images/4.jpg"
import './style.css'


const App=function(){
  return(
    <div className=''>
      <div className=  'ui comments'>
    <User_feedback>
     
     
    
      <User 
      name="Ms Lisa"
      date='09:30AM' 
      msg="I'm feeling amazed"
      picture={bunny}
      />
      </User_feedback>  

      <User_feedback>
      <User name="Mr. Mask"
      date="10:26AM"
      msg="Where is the party?"
      picture={fox}
      />
      </User_feedback>

      <User_feedback>
      <User name="Mrs Alian"
      DATE="1:52pm"
      msg="Where am I?"
      picture={deer}
      />
      </User_feedback>
      </div> 
    {/* Activity */}
   {/*Wrapper hold all the cards  */}
<div className="Wrapper">
<CardExample
picture={pic1}
title="Open Water Diver"
description="The PADI Open Water Diver course is the world’s most popular scuba program and has introduced millions of people to the world beneath the waves."
/>
<CardExample
picture={pic2}
title="Advanced Open Water Diver"
description="You’ll get the chance to experience the most unique and fun diving activities all in 2 days! "
/>
<CardExample
picture={pic3}
title="Rescue Diver"
description="The PADI Rescue Diver course is probably one of the most fun, exciting and rewarding PADI Course out there!"
/>
<CardExample
picture={pic4}
title="Discover Scuba Diving"
description="Experience the thrill of diving in one day with the PADI Discover Scuba Diving program!"
/>




</div> 







  </div>
    

   
    
  )

}


// rooting
const root= ReactDOM.createRoot(document.querySelector('#root'))
root.render(App())


/*
// example of props
const App=function(props){
  return(
    <div>
      <h1>Welcome to React function components{props.name}</h1>
    </div>
  )
}
// create a props in a constant
const myElement = <App name="Martha" />;
// rooting
ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);
*/