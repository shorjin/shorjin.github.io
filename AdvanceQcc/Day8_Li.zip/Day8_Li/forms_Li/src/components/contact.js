import React from "react";
const Contact=function(){
    return(
        <div className="ui raised very padded text container segment" style={{marginTop:"3em"}}>
            <h2 className="ui header">About Contact</h2>
            <p>Some text about Contact</p>
        </div>
    )
}

export default Contact;