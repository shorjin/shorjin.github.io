import React from "react";
const Home=function(){
    return(
        <div className="ui raised very padded text container segment" style={{marginTop:"3em"}}>
            <h2 className="ui header">About Home</h2>
            <p>Some text about Home</p>
        </div>
    )
}

export default Home;