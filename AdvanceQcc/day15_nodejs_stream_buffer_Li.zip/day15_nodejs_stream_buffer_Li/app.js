// import module from nodejs library
const fs = require('fs')
const http = require('http')

// create a readable stream to read file readme.txt
// const readStream=fs.createReadStream('index.html')
const writeStream=fs.createWriteStream("write.txt")

//Creating a server
const server = http.createServer((request, response) => {
    // sending the response



    response.writeHead(200, {'Content-Type': 'text/html'});
    // piping
    // readStream.pipe(response)
    
    const url = request.url

    if (url === '/home' || url === '/') {
        fs.createReadStream('index.html').pipe(response)
    } else if (url === '/about') {
        fs.createReadStream('about.html').pipe(response)
    } else {
        fs.createReadStream('404.html').pipe(response)
    }
   
});

//server listening to port 3000
server.listen((3000), () => {
    console.log('Server listening on port 3000')
})





/*


// STREAMS AND BUFFERS
// create a readable stream to read readme file
const fs = require('fs')
const readStream=fs.createReadStream('readme.txt')
const writeStream=fs.createWriteStream("write.txt")

// listen to the stream to read file readme.txt this will fill up the buffer

readStream.on('data', (d) => {
    console.log('\n-------------- new data received')
    // buffer stream
    console.log(d)
    console.log('\n---------------------------------------------------\n')

    // showdata 
    console.log(`\n${d}`)
    console.log('\n---------------------------------------------------\n')
    writeStream.write(d)
});

readStream.on('open', () => {
    console.log('\n\nStream Opened')
});

readStream.on('end', () => {
    console.log('Stream closed!...\n\n')
});


// writeStream

writeStream.write('Streaming Text Content\n', 'utf-8')

*/



/*
//CREATING A SERVER IN NODEJS
//Importing the HTTP module
const http = require('http');

//Creating a server
const server = http.createServer((request, response) => {
    //sending the response
    response.write('This is the response from the server.')
    response.end('\n------- end ---------\n');
    console.log(request.url);
});

//server listening to port 3000
server.listen((3000), () => {
    console.log('Server is running a localhost:3000')
})
*/