const fs = require('fs')

//remove directory
fs.rmdirSync('newDir')

//add directory
fs.mkdirSync('newDir')
// asyn to create directory
fs.mkdir('images', function(e) {
    if (e) {
        console.log(e)
    } 
    console.log("images Directory created successfully!")
})

// create a synchronous file using writeFileSync()
let fileContent = 'This file has three names:\n1. Peter\n2. Martha\n3. Jason'
fs.writeFileSync('write.txt', fileContent, 'utf-8')

//  create an asynchronous file using writeFile()
let msg = "Welcome to the nodejs I/O files"
 fs.writeFile('msg.txt', msg, 'utf-8', function(error) {
     if (error) {
         console.log(error)
     }
});

//append information into an existing File
let addNames = '\n4. George\n5. Ann'
//fs.appendFileSync('write.txt', addNames, 'ascii')
fs.appendFile('write.txt', addNames, 'utf-8', function(error) {
    if (error) {
        console.log(error)
    }
})

// remove an existing file
fs.unlink('msg.txt', function (error) {
    console.log(error)
})


// overwriting file 'write.txt' by "HELLO"
//fs.writeFileSync('write.txt', 'HELLO!', 'utf-8')

// asynchonous read module
console.log('Line before readFile')
fs.readFile('README.txt', 'utf-8', function(error, data) {
    console.log('\n********async read file *******')
    console.log(data)
})

console.log('Line after readFile')
let sum = 5+20;
console.log(`Sum = ${sum}`)

// synchonous read module
console.log('Line before readFileSync')
console.log('\n*******sync read file *******')
let fileRead = fs.readFileSync('readme.txt', 'utf-8')
console.log(fileRead)
console.log('Line after readFileSync')