const helper = function(data) {
    return `${data} is logged in!`
};

const id = function(i) {
    return `ID is ${i}`
}

let email = function(e) {
    return `Email is ${e}`
}

//one line export object
module.exports = {
    helper, id, email
}
/*
//multiple line export objects
module.exports.helper = helper
module.exports.id = id
module.exports.email = email
*/