const name = require('./mod')

console.log(name.helper('Peter'))
console.log(name.id(123))
console.log(name.email('peterpan@neverland.com'))

/*
function callColor(innerFunction) {
    innerFunction()
};

let color = function() {
    console.log("Passing a function")
}
console.log(callColor(color))
*/




/*
let count = 0;

const timer = setInterval(() => {
    count += 2
    console.log(`counting ${count} seconds`)

    if (count == 10) {
        clearInterval(timer)
    }

}, 2000);
*/



/*
// global objects
setTimeout(() => {
    console.log("welcome to NodeJS")
}, 3000)
*/


/*
//console module
console.warn("Warning! Error in the code.")
console.error("ERROR Syntax error at line 5")
console.trace("Trace the code below")
*/

