const events = require('events')
const util = require('util')

// Inheritance Module
const teams = function(name) {
    this.name = name
}

// EventEmitter will inherit any of teams in the constructor
util.inherits(teams, events.EventEmitter)

//this team is going to to inherit from the events
const Barcelona = new teams('Barcelona')
const Milan = new teams('Milan')

// Save each constructor in an Array
const teamsArray = [Barcelona, Milan]

// Print each team using forEach loop
teamsArray.forEach((t) => {
    t.on('nation', function(n) {
        console.log(t.name + ' is ' + n + ' soccer club!')
    });
});

// emit the eventEmitter,use nation event, and pass the parameter n
Milan.emit('nation', 'Italian')
Barcelona.emit('nation', 'Spain')



// example of events module
const eventEmitter = new events.EventEmitter
// call this event's name test

eventEmitter.on('test', function(a) {
    console.log(a)
})
// run the event emit, run test
eventEmitter.emit('test', 'EVENT IN NODEJS')